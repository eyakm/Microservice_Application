package org.ms.eurekadiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
